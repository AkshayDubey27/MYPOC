import React, { useState } from 'react';
import './Stepper.css'
import PropTypes from 'prop-types'
/**
 * Name: Stepper
 * @param {any} props

 * @returns node
 */

const Stepper = (props) => {

    const [activeStep, setActiveStep] = useState(props.steps[0]);
    const handleNext = () => {
        if (props.steps[props.steps.length - 1].key === activeStep.key) {
            return;
        }

        const index = props.steps.findIndex(x => x.key === activeStep.key);
        props.setSteps(prevStep => prevStep.map(x => {
            if (x.key === activeStep.key) x.isDone = true;
            return x;
        }))
        setActiveStep(props.steps[index + 1]);
    }

    const handleBack = () => {
        const index = props.steps.findIndex(x => x.key === activeStep.key);
        if (index === 0) return;

        props.setSteps(prevStep => prevStep.map(x => {
            if (x.key === activeStep.key) x.isDone = false;
            return x;
        }))
        setActiveStep(props.steps[index - 1]);
    }

    return (
        <div>
            <div className="box">
                <div className="steps">
                    <ul>
                        {props.steps.map((step, i) => {
                            return <li key={i} className={`${activeStep.key === step.key ? 'active' : ''} ${step.isDone ? 'done' : ''}`}>
                                <div>Step {i + 1}<br /><span>{step.label}</span></div>
                            </li>
                        })}
                    </ul>
                </div>
                <div className="step-component">
                    {activeStep.label}
                </div>
                <div className="btn-component">
                    <button type="button"  onClick={handleBack} disabled={props.steps[0].key === activeStep.key} >Back</button>
                    <button type="button" onClick={handleNext} >{props.steps[props.steps.length - 1].key !== activeStep.key ? 'Next' : 'Submit'}</button>
                </div>
            </div>
        </div>
    );
}
Stepper.defaultProps = {
    steps:[{ key: 'Default1', label: 'Default Step1', isDone: true},
    { key: 'Default2', label: 'Default Step2', isDone: false},
    { key: 'Default3', label: 'Default Step3', isDone: false},
    { key: 'Default4', label: 'Default Step4', isDone: false},],
    setSteps: function(){
       return true;
    }
}

Stepper.propTypes = {
    props: PropTypes.any,
}

export default Stepper;
