import { useState } from 'react';
import './App.css';
import CustomSelect from './shared/CustomSelect/CustomSelect';
import Stepper from './shared/Stepper/Stepper';
function App() {

// data for dropdown
const optionsList = [
    "Option 1",
    "Option 2",
    "Option 3",
    "Option 4",
    "Option 5"
  ];
//json data for stepper
const [steps, setSteps] = useState([
    { key: 'firstStep', label: 'My First Step', isDone: true},
    { key: 'secondStep', label: 'My Second Step', isDone: false},
    { key: 'thirdStep', label: 'My Third Step', isDone: false},
    { key: 'finalStep', label: 'My Final Step', isDone: false},
  ]);
  return (
    <div className="App">
      <p>Select DropDown</p>
      <CustomSelect />
      <p>Stepper</p>
      <Stepper/>
    </div>
  );
}

export default App;
